init.py
: 初始化node的腳本，可以放至 launch template 讓他自動啟動

get_info.py
: 取得 Chord node 的各項資訊

find_ip.py
: 用來確認 a.txt 經過 hash 之後應該要放在哪個 node，實驗中有提到這個輔助用途

kill.py
: kill chord node